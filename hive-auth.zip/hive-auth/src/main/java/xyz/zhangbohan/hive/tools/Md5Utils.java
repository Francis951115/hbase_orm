/*
 * Copyright (c) 2019. zhangbohan.dell@gmail.com ,All Rights Reserved
 *
 */

package xyz.zhangbohan.hive.tools;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
/**
 * file encoding: utf-8
 * Function :
 * Create : 4/16/2019 3:50 PM
 *
 * @author : zhangbohan.dell@gmail.com
 * @version : 1.0
 */
public class Md5Utils {

	private static MessageDigest digest;
	private static char hexDigits[] = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f'};
	static  {
		try {
			digest = MessageDigest.getInstance("MD5");
		} catch (NoSuchAlgorithmException e) {
			throw new RuntimeException(e);
		}
	}

	public static String encrypt(String str) {
		byte[] btInput = str.getBytes();
		digest.reset();
		digest.update(btInput);
		byte[] md = digest.digest();
		// 把密文转换成十六进制的字符串形式
		int j = md.length;
		char strChar[] = new char[j * 2];
		int k = 0;
		for (int i = 0; i < j; i++) {
			byte byte0 = md[i];
			strChar[k++] = hexDigits[byte0 >>> 4 & 0xf];
			strChar[k++] = hexDigits[byte0 & 0xf];
		}
		return new String(strChar);
	}
}
