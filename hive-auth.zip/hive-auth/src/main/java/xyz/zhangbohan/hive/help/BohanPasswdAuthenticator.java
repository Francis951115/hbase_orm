/*
 * Copyright (c) 2019. zhangbohan.dell@gmail.com ,All Rights Reserved
 *
 */

package xyz.zhangbohan.hive.help;

import org.apache.hadoop.conf.Configurable;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hive.conf.HiveConf;
import org.apache.hadoop.util.ReflectionUtils;
import org.apache.hive.service.auth.PasswdAuthenticationProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xyz.zhangbohan.hive.tools.Md5Utils;

import javax.security.sasl.AuthenticationException;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
/**
 * file encoding: utf-8
 * Function :
 * Create : 4/16/2019 3:41 PM
 *
 * @author : zhangbohan.dell@gmail.com
 * @version : 1.0
 */
public class BohanPasswdAuthenticator implements PasswdAuthenticationProvider {

	 private static final Logger logger = LoggerFactory.getLogger(BohanPasswdAuthenticator.class);

	private HiveConf conf = new HiveConf();

	BohanPasswdAuthenticator(HiveConf conf) {
		this.conf = conf;
	}

	public BohanPasswdAuthenticator() {
	}
	public void Authenticate(String username, String password)
			throws AuthenticationException {

		boolean ok = false;
		String passMd5 = Md5Utils.encrypt(password);
		Configuration conf = new Configuration(this.conf);
		String filePath = conf.get("hive.server2.custom.authentication.file");
		logger.info("hive.server2.custom.authentication.file [" + filePath + "] ..");
		File file = new File(filePath);
		BufferedReader reader = null;
		try {
			reader = new BufferedReader(new FileReader(file));
			String tempString = null;
			while ((tempString = reader.readLine()) != null) {
				String[] datas = tempString.split(",", -1);
				if(datas.length != 2) {
					continue;};
				//ok
				if(datas[0].equals(username) && datas[1].equals(passMd5)) {
					ok = true;
					break;
				}
			}
			reader.close();
		} catch (Exception e) {
			e.printStackTrace();
			throw new AuthenticationException("read auth config file error, [" + filePath + "] ..", e);
		} finally {
			if (reader != null) {
				try {
					reader.close();
				} catch (IOException e1) {}
			}
		}
		if(ok) {
			logger.info("user [" + username + "] auth check ok .. ");
		} else {
			logger.error("user [" + username + "] auth check fail .. ");
			throw new AuthenticationException("user [" + username + "] auth check fail .. ");
		}
	}


}
